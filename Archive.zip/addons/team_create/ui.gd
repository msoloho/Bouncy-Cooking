@tool
extends Control

var network: Node

# UI Elements
var status_panel: PanelContainer
var status_label: Label
var users_label: RichTextLabel
var server_msg_label: Label
var ip_edit: LineEdit
var username_edit: LineEdit
var host_btn: Button
var join_btn: Button
var disconnect_btn: Button

var sync_settings_btn: Button
var update_btn: Button

var export_btn: Button
var export_dialog: FileDialog
var backup_scene_btn: Button


var lan_container: VBoxContainer
var sync_status_btn: Button



var _ui_built = false
var _bold_labels = []
var title_label: Label
var status_header: Label
var profile_header: Label
var conn_header: Label
var sync_header: Label

func _notification(what: int) -> void:
	if what == NOTIFICATION_THEME_CHANGED or what == NOTIFICATION_READY:
		_apply_theme_overrides()

func _init() -> void:
	name = "Team Create"
	_build_ui()

func _apply_theme_overrides() -> void:
	if not is_inside_tree():
		return
	var bold_font = get_theme_font("bold", "Label") if has_theme_font("bold", "Label") else null
	if bold_font:
		for lbl in _bold_labels:
			if is_instance_valid(lbl):
				lbl.add_theme_font_override("font", bold_font)

func _get_editor_settings() -> EditorSettings:
	if Engine.is_editor_hint() and ClassDB.class_exists("EditorInterface"):
		return EditorInterface.get_editor_settings()
	if network and network.plugin and network.plugin.has_method("get_editor_interface"):
		return network.plugin.get_editor_interface().get_editor_settings()
	return null

func _build_ui() -> void:
	if _ui_built:
		return
	_ui_built = true

	var scroll = ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 5)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)

	var main_vbox = VBoxContainer.new()
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_theme_constant_override("separation", 10)
	scroll.add_child(main_vbox)

	# --- Title ---
	title_label = Label.new()
	title_label.text = "Godot Team Create"
	title_label.add_theme_font_size_override("font_size", 18)
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bold_labels.append(title_label)
	main_vbox.add_child(title_label)

	# --- Panel Style ---
	var panel_style = StyleBoxFlat.new()
	panel_style.bg_color = Color(0.15, 0.15, 0.15, 1.0) # Dark grey background
	panel_style.corner_radius_top_left = 8
	panel_style.corner_radius_top_right = 8
	panel_style.corner_radius_bottom_left = 8
	panel_style.corner_radius_bottom_right = 8
	panel_style.content_margin_left = 10
	panel_style.content_margin_right = 10
	panel_style.content_margin_top = 10
	panel_style.content_margin_bottom = 10

	# --- Status & Users Panel ---
	status_panel = PanelContainer.new()
	status_panel.add_theme_stylebox_override("panel", panel_style)
	status_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(status_panel)

	var status_vbox = VBoxContainer.new()
	status_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	status_panel.add_child(status_vbox)

	status_header = Label.new()
	status_header.text = "Status & Users"
	status_header.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bold_labels.append(status_header)
	status_vbox.add_child(status_header)

	status_label = Label.new()
	status_label.text = "Status: Disconnected"
	status_label.add_theme_color_override("font_color", Color.GRAY)
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	status_vbox.add_child(status_label)

	server_msg_label = Label.new()
	server_msg_label.add_theme_color_override("font_color", Color.YELLOW)
	server_msg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	server_msg_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	server_msg_label.hide()
	status_vbox.add_child(server_msg_label)

	status_panel.hide()

	users_label = RichTextLabel.new()
	users_label.bbcode_enabled = true
	users_label.text = "Users: 1"
	users_label.fit_content = true
	users_label.scroll_active = false
	users_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	users_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	status_vbox.add_child(users_label)

	# --- Profile Panel ---
	var profile_panel = PanelContainer.new()
	profile_panel.add_theme_stylebox_override("panel", panel_style)
	profile_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(profile_panel)

	var profile_vbox = VBoxContainer.new()
	profile_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	profile_panel.add_child(profile_vbox)

	profile_header = Label.new()
	profile_header.text = "Profile"
	profile_header.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	profile_header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bold_labels.append(profile_header)
	profile_vbox.add_child(profile_header)

	username_edit = LineEdit.new()
	username_edit.placeholder_text = "Display Name"
	username_edit.tooltip_text = "Your username across all projects. Max 15 characters."
	username_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	username_edit.max_length = 15
	username_edit.text_changed.connect(_on_username_changed)
	profile_vbox.add_child(username_edit)

	# --- Connectivity Panel ---
	var conn_panel = PanelContainer.new()
	conn_panel.add_theme_stylebox_override("panel", panel_style)
	conn_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(conn_panel)

	var conn_vbox = VBoxContainer.new()
	conn_vbox.add_theme_constant_override("separation", 8)
	conn_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	conn_panel.add_child(conn_vbox)

	conn_header = Label.new()
	conn_header.text = "Connectivity"
	conn_header.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	conn_header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bold_labels.append(conn_header)
	conn_vbox.add_child(conn_header)

	# LAN Container
	lan_container = VBoxContainer.new()
	lan_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	conn_vbox.add_child(lan_container)

	ip_edit = LineEdit.new()
	ip_edit.text = "127.0.0.1"
	ip_edit.placeholder_text = "Host IP Address (e.g., 127.0.0.1)"
	ip_edit.tooltip_text = "Enter the IP address of the host you want to join over LAN."
	ip_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ip_edit.clear_button_enabled = true
	ip_edit.select_all_on_focus = true
	ip_edit.text_changed.connect(_on_ip_changed)
	lan_container.add_child(ip_edit)

	var lan_btn_hbox = HBoxContainer.new()
	lan_btn_hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lan_container.add_child(lan_btn_hbox)

	host_btn = Button.new()
	host_btn.text = "Host LAN"
	host_btn.tooltip_text = "Starts server on LAN and automatically connects you to it."
	host_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	host_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	host_btn.pressed.connect(_on_host_pressed)
	lan_btn_hbox.add_child(host_btn)

	join_btn = Button.new()
	join_btn.text = "Join"
	join_btn.tooltip_text = "Join an existing LAN server using the IP above."
	join_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	join_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	join_btn.pressed.connect(_on_join_pressed)
	lan_btn_hbox.add_child(join_btn)

	# Disconnect Button (shared at bottom of connectivity)
	var disconnect_style = StyleBoxFlat.new()
	disconnect_style.bg_color = Color(0.15, 0.15, 0.15, 1.0)
	disconnect_style.border_width_left = 1
	disconnect_style.border_width_right = 1
	disconnect_style.border_width_top = 1
	disconnect_style.border_width_bottom = 1
	disconnect_style.border_color = Color.INDIAN_RED
	disconnect_style.corner_radius_top_left = 6
	disconnect_style.corner_radius_top_right = 6
	disconnect_style.corner_radius_bottom_left = 6
	disconnect_style.corner_radius_bottom_right = 6

	disconnect_btn = Button.new()
	disconnect_btn.text = "Disconnect"
	disconnect_btn.tooltip_text = "Disconnect from the current session."
	disconnect_btn.disabled = true
	disconnect_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	disconnect_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	disconnect_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	disconnect_btn.add_theme_color_override("font_color", Color.INDIAN_RED)
	disconnect_btn.add_theme_color_override("font_disabled_color", Color(0.5, 0.2, 0.2))
	disconnect_btn.add_theme_stylebox_override("normal", disconnect_style)
	disconnect_btn.pressed.connect(_on_disconnect_pressed)
	conn_vbox.add_child(disconnect_btn)

	# --- Synchronization Panel ---
	var sync_panel = PanelContainer.new()
	sync_panel.add_theme_stylebox_override("panel", panel_style)
	sync_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_vbox.add_child(sync_panel)

	var sync_vbox = VBoxContainer.new()
	sync_vbox.add_theme_constant_override("separation", 8)
	sync_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sync_panel.add_child(sync_vbox)

	sync_header = Label.new()
	sync_header.text = "Synchronization"
	sync_header.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sync_header.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bold_labels.append(sync_header)
	sync_vbox.add_child(sync_header)

	var sync_status_style = StyleBoxFlat.new()
	sync_status_style.bg_color = Color(0.2, 0.3, 0.2, 1.0)
	sync_status_style.corner_radius_top_left = 6
	sync_status_style.corner_radius_top_right = 6
	sync_status_style.corner_radius_bottom_left = 6
	sync_status_style.corner_radius_bottom_right = 6

	sync_status_btn = Button.new()
	sync_status_btn.text = "Not connected"
	sync_status_btn.add_theme_color_override("font_color", Color.GRAY)
	sync_status_btn.add_theme_stylebox_override("normal", sync_status_style)
	sync_status_btn.add_theme_stylebox_override("disabled", sync_status_style)
	sync_status_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sync_status_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sync_status_btn.disabled = true
	sync_vbox.add_child(sync_status_btn)

	sync_settings_btn = Button.new()
	sync_settings_btn.text = "Sync Project Settings"
	sync_settings_btn.tooltip_text = "(Server only) Force push project.godot to all clients."
	sync_settings_btn.disabled = true
	sync_settings_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	sync_settings_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sync_settings_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sync_settings_btn.pressed.connect(_on_sync_settings_pressed)
	sync_vbox.add_child(sync_settings_btn)

	export_btn = Button.new()
	export_btn.text = "Export Headless Server"
	export_btn.tooltip_text = "Generate standalone server scripts to host without the Godot editor."
	export_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	export_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	export_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	export_btn.pressed.connect(_on_export_pressed)
	sync_vbox.add_child(export_btn)

	backup_scene_btn = Button.new()
	backup_scene_btn.text = "Create Backup"
	backup_scene_btn.tooltip_text = "Create a timestamped snapshot backup of the current scene."
	backup_scene_btn.disabled = true
	backup_scene_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	backup_scene_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	backup_scene_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	backup_scene_btn.pressed.connect(_on_backup_scene_pressed)
	sync_vbox.add_child(backup_scene_btn)

	main_vbox.add_child(HSeparator.new())

	update_btn = Button.new()
	update_btn.text = "Check for Updates"
	update_btn.tooltip_text = "Check GitHub for newer versions of the Godot Team Create plugin."
	update_btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	update_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	update_btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	update_btn.pressed.connect(_on_update_pressed)
	main_vbox.add_child(update_btn)

	export_dialog = FileDialog.new()
	export_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	export_dialog.access = FileDialog.ACCESS_FILESYSTEM
	export_dialog.title = "Select Output Directory for Server Export"
	export_dialog.dir_selected.connect(_on_export_dir_selected)
	add_child(export_dialog)


func _ready() -> void:
	_build_ui()
	_apply_theme_overrides()

	var settings = _get_editor_settings()
	if settings:
		if settings.has_setting("team_create/username"):
			var saved_name = settings.get_setting("team_create/username")
			if saved_name != "":
				username_edit.text = saved_name
				_on_username_changed(saved_name)

		if settings.has_setting("team_create/last_ip"):
			var saved_ip = settings.get_setting("team_create/last_ip")
			if saved_ip != "":
				ip_edit.text = saved_ip
				_on_ip_changed(saved_ip)

func set_connected(is_host: bool, connected_to_standalone: bool = false) -> void:
	host_btn.disabled = true
	join_btn.disabled = true
	disconnect_btn.disabled = false
	sync_settings_btn.disabled = false
	backup_scene_btn.disabled = false
	sync_status_btn.text = "✓ Up to date!"
	sync_status_btn.add_theme_color_override("font_color", Color.LIGHT_GREEN)

	status_panel.show()
	var username = username_edit.text if username_edit.text != "" else "You"
	if is_host:
		status_label.text = "Status: Connected (Host)\nUser: " + username
		status_label.add_theme_color_override("font_color", Color.GREEN)
	else:
		if connected_to_standalone:
			status_label.text = "Status: Connected to Server\nUser: " + username
		else:
			status_label.text = "Status: Connected (Client)\nUser: " + username
		status_label.add_theme_color_override("font_color", Color.GREEN)

func set_disconnected() -> void:
	host_btn.disabled = false
	join_btn.disabled = false
	disconnect_btn.disabled = true
	sync_settings_btn.disabled = true
	backup_scene_btn.disabled = true
	sync_status_btn.text = "Not connected"
	sync_status_btn.add_theme_color_override("font_color", Color.GRAY)

	status_panel.hide()

	status_label.text = "Status: Disconnected"
	status_label.add_theme_color_override("font_color", Color.GRAY)
	users_label.text = "Users: 1"

func update_users_count(count: int) -> void:
	if network:
		var visible_count = count
		var has_standalone = false
		if network.peers.has(1) and network.peers[1].has("is_standalone") and network.peers[1]["is_standalone"]:
			has_standalone = true
			visible_count -= 1

		var text = "Users: " + str(visible_count) + "\n"
		var my_id = 0
		if network and network.is_connected_to_session():
			my_id = network.multiplayer.get_unique_id()

		for peer_id in network.peers:
			if peer_id == 1 and has_standalone:
				continue

			var username = network.get_username(peer_id)
			var color = network.get_user_color(peer_id).to_html()
			if my_id != 0 and peer_id == my_id:
				text += "[color=#" + color + "]" + username + " (You)[/color]\n"
			else:
				text += "[color=#" + color + "]" + username + "[/color]\n"
		users_label.text = text
	else:
		users_label.text = "Users: " + str(count)

func show_server_message(msg: String) -> void:
	if server_msg_label:
		server_msg_label.text = msg
		server_msg_label.show()
		var t = get_tree().create_timer(5.0)
		t.timeout.connect(func():
			if is_instance_valid(server_msg_label):
				server_msg_label.hide()
		)

func _on_username_changed(new_text: String) -> void:
	var settings = _get_editor_settings()
	if settings:
		settings.set_setting("team_create/username", new_text)
	if network:
		network.update_local_username(new_text)

func _on_ip_changed(new_text: String) -> void:
	var settings = _get_editor_settings()
	if settings:
		settings.set_setting("team_create/last_ip", new_text)

func _on_host_pressed() -> void:
	if network:
		network.host_lan_server(ip_edit.text)

func _on_join_pressed() -> void:
	if network:
		if network.has_method("stop_local_server"):
			network.stop_local_server()
		network.join_server(ip_edit.text)

func _on_disconnect_pressed() -> void:
	if network:
		network.disconnect_peer(true)
		if network.has_method("stop_local_server"):
			network.stop_local_server()

func _on_sync_settings_pressed() -> void:
	if network:
		network.sync_project_settings()

func _on_backup_scene_pressed() -> void:
	if network:
		network.create_backup()
		backup_scene_btn.text = "✓ Backup Created!"
		get_tree().create_timer(2.5).timeout.connect(func():
			if is_instance_valid(backup_scene_btn):
				backup_scene_btn.text = "Create Backup"
		)

func _on_update_pressed() -> void:
	if network and network.plugin:
		if update_btn.text == "Update Available!":
			network.plugin.download_update()
		else:
			update_btn.text = "Checking..."
			update_btn.disabled = true
			network.plugin.check_for_updates()


func _on_export_pressed() -> void:
	if export_dialog:
		export_dialog.popup_centered_ratio(0.5)

func _on_export_dir_selected(dir: String) -> void:
	if network and network.plugin:
		var exporter_script = load("res://addons/team_create/server_exporter.gd")
		if exporter_script:
			# TODO: Add AcceptDialog popup on failure instead of just printing to console
			exporter_script.export_server(dir, self)
		else:
			network.tc_print("Failed to load server_exporter.gd")


func show_error(title: String, message: String) -> void:
	var dialog = AcceptDialog.new()
	dialog.title = title
	dialog.dialog_text = message
	add_child(dialog)
	dialog.popup_centered()
	dialog.confirmed.connect(dialog.queue_free)
	dialog.canceled.connect(dialog.queue_free)
